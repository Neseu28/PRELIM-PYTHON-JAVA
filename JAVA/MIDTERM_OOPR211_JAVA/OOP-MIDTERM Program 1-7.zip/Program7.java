import java.io.*;
import java.util.*;

public class Program7 {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        String choice;

        do {

            System.out.println("==============================");
            System.out.println("     CHOOSE PROGRAM TO RUN");
            System.out.println("==============================");
            System.out.println("1. Program 1");
            System.out.println("2. Program 2");
            System.out.println("3. Program 3");
            System.out.println("4. Program 4");
            System.out.println("5. Program 5");
            System.out.println("6. Program 6");
            System.out.println("7. Read Employee Text File");
            System.out.println("==============================");

            System.out.print("Enter your choice: ");
            int number = input.nextInt();

            System.out.println();

            switch (number) {

                case 1:
                    Program1.main(new String[]{});
                    break;

                case 2:
                    Program2.main(new String[]{});
                    break;

                case 3:
                    Program3.main(new String[]{});
                    break;

                case 4:
                    Program4.main(new String[]{});
                    break;

                case 5:
                    Program5.main(new String[]{});
                    break;

                case 6:
                    Program6.main(new String[]{});
                    break;

                case 7:
                    readEmployeeFile();
                    break;

                default:
                    System.out.println("Invalid choice.");
            }

            System.out.println();
            System.out.print("Do you want to continue? Y/N: ");
            choice = input.next();

            System.out.println();

        } while (choice.equalsIgnoreCase("Y"));

        System.out.println("Program ended.");

        input.close();
    }


    // Program 7 - Read employee text file
   public static void readEmployeeFile() {

    try {

        BufferedReader br =
                new BufferedReader(new FileReader("emp.txt"));

        String line;

        System.out.println("==========================================");
        System.out.println("       EMPLOYEE INFORMATION");
        System.out.println("==========================================");

        System.out.println("ENO\tNAME\t\tMOBILE");
        System.out.println("------------------------------------------");

        while ((line = br.readLine()) != null) {

            // Skip the header
            if (line.startsWith("eno")) {
                continue;
            }

            // Separate data using TAB
            String[] data = line.split("\\t", -1);

            // Make sure there are 3 columns
            if (data.length < 3) {
                System.out.println("WARNING: Incomplete record!");
                continue;
            }

            String eno = data[0].trim();
            String name = data[1].trim();
            String mobile = data[2].trim();

            // Check missing ENO
            if (eno.isEmpty()) {
                System.out.println("WARNING: ENO is missing!");
            }

            // Check missing name
            if (name.isEmpty()) {
                System.out.println(
                    "WARNING: Name is missing for ENO: " + eno
                );
            }

            // Check missing mobile
            if (mobile.isEmpty()) {
                System.out.println(
                    "WARNING: Mobile number is missing for ENO: " + eno
                );
            }

            // Display the record
            System.out.println(
                    eno + "\t" +
                    name + "\t\t" +
                    mobile
            );
        }

        br.close();

    } catch (FileNotFoundException e) {

        System.out.println("WARNING: emp.txt was not found!");

    } catch (IOException e) {

        System.out.println("Error reading the file.");
    }
}
}